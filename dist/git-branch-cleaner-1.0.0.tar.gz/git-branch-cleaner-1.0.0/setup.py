__version__ = "1.0.0"

from setuptools import setup

setup()
